<?php
//error_reporting(E^ALL);
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$conn = new mysqli("localhost", "root", "", "cart");

	$id=10;
	
	if(isset($_GET["id"]) && !empty($_GET["id"]) ){
		$id = $_GET["id"];
		$id = $conn->real_escape_string($id);
	}

	$query="SELECT id, name FROM category where id <=".$id." ";


	if(isset($_GET["name"]) && !empty($_GET["name"]) ){
		
		$name = $_GET["name"];
		$name = stripslashes($name);
		$name = $conn->real_escape_string($name);
		$query=$query."and name like ".$name." ";
		
	}
	
	if( isset($_GET["sort"]) && !empty($_GET["sort"]) ){
		
		$s = $_GET["sort"];
		if($s=="i"){	$query.="order by id";}
		else if($s=="n"){	$query.="order by name";}
		
	}

	
	

$result = $conn->query($query);
$outp = "";
while($rs = $result->fetch_array(MYSQLI_ASSOC)) {
    if ($outp != "") {$outp .= ",";}
        $outp .= '{"id":"'  . $rs["id"] . '",';
	$outp .= '"name":"'. $rs["name"] . '"}';
}


// Adding has more
$result=$conn->query("SELECT count(*) as total from category");
$data=$result->fetch_array(MYSQLI_ASSOC);
$total = $data['total'];

if(($total-$till)>0){$has_more=$total-$till;}
			    else{$has_more=0;}
			
				
	$outp ='{"has_more":'.$has_more.',"records":['.$outp.']}';

	
$conn->close();

echo($outp);
?> 
